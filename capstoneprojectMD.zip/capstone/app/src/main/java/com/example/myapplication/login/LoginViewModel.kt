package com.example.myapplication.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.preference.UserModel
import com.example.myapplication.repository.UserRepository
import kotlinx.coroutines.launch

class LoginViewModel (private val repository: UserRepository) : ViewModel() { //belom ada
    fun saveSession(user: UserModel) { //belom ada
        viewModelScope.launch { //belom ada
            repository.saveSession(user)
        }
    }
}