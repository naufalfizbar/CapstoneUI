package com.example.myapplication.main

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.R
import com.example.myapplication.welcome.WelcomeActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    // Cek status login
    if (!isLoggedIn()) {
        // Jika belum login, arahkan ke WelcomeActivity
        val intent = Intent(this, WelcomeActivity::class.java)
        startActivity(intent)
        finish() // Tutup MainActivity agar tidak bisa kembali dengan tombol back
    }
}

// Fungsi untuk memeriksa status login
private fun isLoggedIn(): Boolean {
    // Implementasikan logika untuk memeriksa status login di sini
    // Misalnya, Anda dapat menggunakan Shared Preferences, database, atau autentikasi Firebase
    // Untuk tujuan contoh, saya akan mengembalikan false
    return false
}
}
